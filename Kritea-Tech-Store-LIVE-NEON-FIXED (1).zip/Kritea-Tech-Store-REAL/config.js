window.KRITEA_CONFIG = {
  CURRENCY: "ALL",
  WHATSAPP: "355692883035",
  PHONE: "+355 69 288 3035",
  MAPS_URL: "https://maps.app.goo.gl/ZWYUWPZ6FDnx1G5b6?g_st=ic",
  INSTAGRAM_URL: "https://www.instagram.com/",
  STORE_NAME: "Kritea Tech Store",
  DEMO_FALLBACK: false
};
