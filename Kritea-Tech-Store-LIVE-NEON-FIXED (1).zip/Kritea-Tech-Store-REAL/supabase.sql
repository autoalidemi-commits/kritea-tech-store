-- KRITEA TECH STORE - SUPABASE SETUP
-- Run this entire file in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  brand text default '',
  category text default '',
  description text default '',
  specifications jsonb default '{}'::jsonb,
  images jsonb default '[]'::jsonb,
  colors jsonb default '[]'::jsonb,
  storage_options jsonb default '[]'::jsonb,
  sim_options jsonb default '[]'::jsonb,
  variants jsonb default '[]'::jsonb,
  stock integer default 0,
  sku text default '',
  warranty text default '',
  featured boolean default false,
  is_new boolean default false,
  offer_active boolean default false,
  old_price numeric,
  new_price numeric,
  hidden boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text unique not null,
  customer jsonb not null default '{}'::jsonb,
  items jsonb not null default '[]'::jsonb,
  total numeric default 0,
  payment_method text default 'Cash on Delivery',
  status text default 'New',
  created_at timestamptz default now()
);

create table if not exists public.service_requests (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  device text default '',
  model text default '',
  problem text default '',
  description text default '',
  photo_urls jsonb default '[]'::jsonb,
  status text default 'New',
  created_at timestamptz default now()
);

create table if not exists public.partners (
  id uuid primary key default gen_random_uuid(),
  business_name text not null,
  logo_url text default '',
  description text default '',
  website_url text default '',
  instagram_url text default '',
  facebook_url text default '',
  video_url text default '',
  image_url text default '',
  cta text default 'Vizito Website-in',
  active boolean default true,
  sort_order integer default 0,
  created_at timestamptz default now()
);

create table if not exists public.pages (
  slug text primary key,
  title text not null,
  content text default '',
  image_url text default '',
  updated_at timestamptz default now()
);

create table if not exists public.homepage_sections (
  id uuid primary key default gen_random_uuid(),
  section_type text not null,
  title text default '',
  subtitle text default '',
  body text default '',
  image_url text default '',
  video_url text default '',
  button_text text default '',
  button_url text default '',
  active boolean default true,
  sort_order integer default 0
);

create table if not exists public.settings (
  key text primary key,
  value jsonb default '{}'::jsonb
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  slug text unique not null,
  description text default '',
  image_url text default '',
  active boolean default true,
  created_at timestamptz default now()
);

create table if not exists public.brands (
  id uuid primary key default gen_random_uuid(),
  name text unique not null,
  logo_url text default '',
  image_url text default '',
  slug text unique not null,
  active boolean default true
);

insert into public.settings(key,value) values
('contact', '{"phone":"+355 69 288 3035","email":"","address":"Tiranë, Shqipëri","hours":"Hënë–Shtunë 09:00–20:00","mapsUrl":"https://maps.app.goo.gl/ZWYUWPZ6FDnx1G5b6?g_st=ic","instagramUrl":"https://www.instagram.com/"}'),
('homepage_hero','{"title":"Teknologjia që do të kesh.","subtitle":"Telefona, laptopë, gaming dhe aksesorë premium nga Kritea Tech Store.","button1":"Shiko produktet","button1Url":"shop.html","button2":"Eksploro iPhone","button2Url":"shop.html?brand=Apple","image":"","video":""}')
on conflict(key) do nothing;

insert into public.pages(slug,title,content) values
('about','Rreth Nesh','Mirë se vini te Kritea Tech Store.'),
('store','Dyqani Ynë','Vizitoni dyqanin tonë në Tiranë.'),
('terms','Kushtet & Termat','Kushtet e përdorimit të Kritea Tech Store.'),
('privacy','Politika e Privatësisë','Politika e privatësisë së Kritea Tech Store.')
on conflict(slug) do nothing;

insert into public.categories(name,slug) values
('iPhone','iphone'),('Samsung','samsung'),('Xiaomi','xiaomi'),('AirPods','airpods'),
('Headphones','headphones'),('Phone Cases','phone-cases'),('Screen Protectors','screen-protectors'),
('Computer Accessories','computer-accessories') on conflict do nothing;

insert into public.brands(name,slug) values ('Apple','apple'),('Samsung','samsung'),('Xiaomi','xiaomi') on conflict do nothing;

-- Storage bucket for product/service media.
insert into storage.buckets(id,name,public) values ('kritea-media','kritea-media',true)
on conflict(id) do nothing;

-- Public read for storefront.
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.service_requests enable row level security;
alter table public.partners enable row level security;
alter table public.pages enable row level security;
alter table public.homepage_sections enable row level security;
alter table public.settings enable row level security;
alter table public.categories enable row level security;
alter table public.brands enable row level security;

create policy "public products read" on public.products for select using (hidden = false);
create policy "public partners read" on public.partners for select using (active = true);
create policy "public pages read" on public.pages for select using (true);
create policy "public home sections read" on public.homepage_sections for select using (active = true);
create policy "public settings read" on public.settings for select using (true);
create policy "public categories read" on public.categories for select using (active = true);
create policy "public brands read" on public.brands for select using (active = true);

-- Order/service creation from storefront.
create policy "public create orders" on public.orders for insert with check (true);
create policy "public create service" on public.service_requests for insert with check (true);

-- Authenticated admin CRUD. For production, restrict these policies to your admin role/email.
create policy "auth products all" on public.products for all to authenticated using (true) with check (true);
create policy "auth orders all" on public.orders for all to authenticated using (true) with check (true);
create policy "auth service all" on public.service_requests for all to authenticated using (true) with check (true);
create policy "auth partners all" on public.partners for all to authenticated using (true) with check (true);
create policy "auth pages all" on public.pages for all to authenticated using (true) with check (true);
create policy "auth home all" on public.homepage_sections for all to authenticated using (true) with check (true);
create policy "auth settings all" on public.settings for all to authenticated using (true) with check (true);
create policy "auth categories all" on public.categories for all to authenticated using (true) with check (true);
create policy "auth brands all" on public.brands for all to authenticated using (true) with check (true);

create policy "public media read" on storage.objects for select using (bucket_id='kritea-media');
create policy "auth media upload" on storage.objects for insert to authenticated with check (bucket_id='kritea-media');
create policy "auth media update" on storage.objects for update to authenticated using (bucket_id='kritea-media');
create policy "auth media delete" on storage.objects for delete to authenticated using (bucket_id='kritea-media');
