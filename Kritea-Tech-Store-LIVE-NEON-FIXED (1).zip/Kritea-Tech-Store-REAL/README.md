# Kritea Tech Store — LIVE: Vercel + Neon + Vercel Blob

Ky version përdor:
- **Vercel** për website + API/serverless backend
- **Neon Postgres** për databazën
- **Vercel Blob** për fotot/videot/media
- Admin login server-side me cookie HttpOnly
- Pa Supabase dhe pa Next.js

## 1. Neon
1. Krijo një projekt në Neon.
2. Hape SQL Editor.
3. Kopjo të gjithë `neon.sql` dhe bëj Run.
4. Merr `DATABASE_URL` nga Neon.

## 2. Vercel
Ngarko këtë folder/ZIP si project në Vercel.
Vercel do instalojë `package.json` dhe do aktivizojë `/api/*`.

Te **Project → Settings → Environment Variables** vendos:
- `DATABASE_URL` = connection string i Neon
- `ADMIN_EMAIL` = emaili që do përdorësh për Admin
- `ADMIN_PASSWORD` = passwordi i Admin
- `AUTH_SECRET` = një secret i gjatë/random
- `BLOB_READ_WRITE_TOKEN` = tokeni i Vercel Blob

Pastaj bëj **Redeploy**.

## 3. Vercel Blob
Krijo një Blob Store te Vercel dhe merr `BLOB_READ_WRITE_TOKEN`.
Admin përdor `/api/upload` për foto; fotot ruhen online dhe URL ruhet në Neon.

## 4. Admin
Hap:
`https://DOMAIN-I-YT.vercel.app/admin.html`

Hyr me `ADMIN_EMAIL` + `ADMIN_PASSWORD` që vendose në Vercel.

Nga Admin mund të menaxhosh produktet, variantet Color/Storage/SIM, çmimet, stock, ofertat, kategoritë, brandet, porositë, servisin, partnerët, faqet, homepage dhe settings.

## 5. Kontrollo live
Hap:
`https://DOMAIN-I-YT.vercel.app/api/health`

Duhet të kthejë `database: Neon connected`.

## Shënim i rëndësishëm
Mos vendos `DATABASE_URL`, `ADMIN_PASSWORD`, `AUTH_SECRET` ose `BLOB_READ_WRITE_TOKEN` në HTML/JS. Ato duhet të jenë vetëm në Vercel Environment Variables.
