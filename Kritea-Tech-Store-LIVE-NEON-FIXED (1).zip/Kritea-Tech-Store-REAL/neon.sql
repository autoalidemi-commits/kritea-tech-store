-- KRITEA TECH STORE — NEON / POSTGRES
-- Run this once in Neon SQL Editor.
create extension if not exists pgcrypto;

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  brand text default '', category text default '', description text default '',
  specifications jsonb default '{}'::jsonb, images jsonb default '[]'::jsonb,
  colors jsonb default '[]'::jsonb, storage_options jsonb default '[]'::jsonb,
  sim_options jsonb default '[]'::jsonb, variants jsonb default '[]'::jsonb,
  stock integer default 0, sku text default '', warranty text default '',
  featured boolean default false, is_new boolean default false, offer_active boolean default false,
  old_price numeric, new_price numeric, hidden boolean default false,
  created_at timestamptz default now(), updated_at timestamptz default now()
);
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  order_number text unique not null, customer jsonb not null default '{}'::jsonb,
  items jsonb not null default '[]'::jsonb, total numeric default 0,
  payment_method text default 'Cash on Delivery', status text default 'New', created_at timestamptz default now()
);
create table if not exists service_requests (
  id uuid primary key default gen_random_uuid(), customer_name text not null, phone text not null,
  device text default '', model text default '', problem text default '', description text default '',
  photo_urls jsonb default '[]'::jsonb, status text default 'New', created_at timestamptz default now()
);
create table if not exists partners (
  id uuid primary key default gen_random_uuid(), business_name text not null, logo_url text default '',
  description text default '', website_url text default '', instagram_url text default '', facebook_url text default '',
  video_url text default '', image_url text default '', cta text default 'Vizito Website-in',
  active boolean default true, sort_order integer default 0, created_at timestamptz default now()
);
create table if not exists pages (
  slug text primary key, title text not null, content text default '', image_url text default '', updated_at timestamptz default now()
);
create table if not exists homepage_sections (
  id uuid primary key default gen_random_uuid(), section_type text not null, title text default '', subtitle text default '',
  body text default '', image_url text default '', video_url text default '', button_text text default '', button_url text default '',
  active boolean default true, sort_order integer default 0
);
create table if not exists settings (key text primary key, value jsonb default '{}'::jsonb);
create table if not exists categories (
  id uuid primary key default gen_random_uuid(), name text unique not null, slug text unique not null,
  description text default '', image_url text default '', active boolean default true, created_at timestamptz default now()
);
create table if not exists brands (
  id uuid primary key default gen_random_uuid(), name text unique not null, logo_url text default '', image_url text default '', slug text unique not null, active boolean default true
);

insert into settings(key,value) values
('contact','{"phone":"+355 69 288 3035","email":"","address":"Tiranë, Shqipëri","hours":"Hënë–Shtunë 09:00–20:00","mapsUrl":"https://maps.app.goo.gl/ZWYUWPZ6FDnx1G5b6?g_st=ic","instagramUrl":"https://www.instagram.com/"}'),
('homepage_hero','{"title":"Teknologjia që do të kesh.","subtitle":"Telefona, laptopë, gaming dhe aksesorë premium nga Kritea Tech Store.","button1":"Shiko produktet","button1Url":"shop.html","button2":"Eksploro iPhone","button2Url":"shop.html?brand=Apple","image":"","video":""}')
on conflict(key) do nothing;
insert into pages(slug,title,content) values
('about','Rreth Nesh','Mirë se vini te Kritea Tech Store.'),
('store','Dyqani Ynë','Vizitoni dyqanin tonë në Tiranë.'),
('terms','Kushtet & Termat','Kushtet e përdorimit të Kritea Tech Store.'),
('privacy','Politika e Privatësisë','Politika e privatësisë së Kritea Tech Store.')
on conflict(slug) do nothing;
insert into categories(name,slug) values
('iPhone','iphone'),('Samsung','samsung'),('Xiaomi','xiaomi'),('AirPods','airpods'),('Headphones','headphones'),('Phone Cases','phone-cases'),('Screen Protectors','screen-protectors'),('Computer Accessories','computer-accessories')
on conflict(name) do nothing;
insert into brands(name,slug) values ('Apple','apple'),('Samsung','samsung'),('Xiaomi','xiaomi') on conflict(name) do nothing;

create index if not exists products_brand_idx on products(brand);
create index if not exists products_category_idx on products(category);
create index if not exists products_sku_idx on products(sku);
create index if not exists orders_status_idx on orders(status);
create index if not exists service_status_idx on service_requests(status);

-- Optional demo products. They are real DB rows but have no images until you upload them from Admin.
insert into products(name,brand,category,description,specifications,colors,storage_options,sim_options,variants,stock,sku,warranty,featured,is_new,offer_active,old_price,new_price)
select 'iPhone 17 Pro Max','Apple','iPhone','Flagship iPhone me performancë premium.','{"Display":"6.9-inch","Camera":"48MP","Processor":"A19 Pro","Battery":"All-day","OS":"iOS","Connectivity":"5G"}',
'[{"name":"Blue","hex":"#3155c9","images":[]},{"name":"Black","hex":"#171717","images":[]},{"name":"Silver","hex":"#d8d8d8","images":[]}]',
'["128GB","256GB","512GB","1TB","2TB"]','["eSIM","Physical SIM","eSIM + Physical SIM"]',
'[{"color":"Blue","storage":"128GB","sim":"eSIM","price":100000,"stock":5},{"color":"Blue","storage":"256GB","sim":"eSIM","price":120000,"stock":5},{"color":"Black","storage":"256GB","sim":"Physical SIM","price":125000,"stock":4},{"color":"Silver","storage":"512GB","sim":"eSIM","price":140000,"stock":2}]',16,'KT-IP17PM','12 muaj',true,true,true,130000,119900
where not exists(select 1 from products where sku='KT-IP17PM');
insert into products(name,brand,category,description,specifications,colors,storage_options,sim_options,variants,stock,sku,warranty,featured,is_new)
select 'Samsung Galaxy S25 Ultra','Samsung','Samsung','Galaxy Ultra për përdoruesit që kërkojnë maksimumin.','{"Display":"6.9-inch","Camera":"200MP","Processor":"Snapdragon","Battery":"5000mAh","OS":"Android","Connectivity":"5G"}',
'[{"name":"Titanium Black","hex":"#242424","images":[]}]','["256GB","512GB","1TB"]','["eSIM","Physical SIM"]',
'[{"color":"Titanium Black","storage":"256GB","sim":"eSIM","price":109900,"stock":4},{"color":"Titanium Black","storage":"512GB","sim":"eSIM","price":124900,"stock":2}]',6,'KT-S25U','12 muaj',true,true
where not exists(select 1 from products where sku='KT-S25U');
insert into products(name,brand,category,description,specifications,colors,variants,stock,sku,warranty,featured,offer_active,old_price,new_price)
select 'AirPods Pro','Apple','AirPods','Kufje wireless premium me ANC.','{"Connectivity":"Bluetooth","Battery":"6h + case","OS":"iOS/Android"}',
'[{"name":"White","hex":"#f5f5f5","images":[]}]','[{"color":"White","storage":"","sim":"","price":24900,"stock":12}]',12,'KT-APP','12 muaj',true,true,29900,24900
where not exists(select 1 from products where sku='KT-APP');
