const { put } = require('@vercel/blob');
const { isAdmin } = require('./auth');
module.exports=async(req,res)=>{
  try{
    if(req.method!=='POST') return res.status(405).json({error:'Method not allowed'});
    if(!process.env.BLOB_READ_WRITE_TOKEN) return res.status(500).json({error:'BLOB_READ_WRITE_TOKEN is missing'});
    let b=req.body||{};if(typeof b==='string'){try{b=JSON.parse(b)}catch{b={}}}
    if(!b.dataUrl || !b.name) return res.status(400).json({error:'Missing file data'});
    if(!b.public && !isAdmin(req)) return res.status(401).json({error:'Admin login required'});
    if(String(b.dataUrl).length>6_000_000) return res.status(413).json({error:'Image is too large'});
    const m=String(b.dataUrl).match(/^data:([^;]+);base64,(.+)$/);if(!m) return res.status(400).json({error:'Invalid data URL'});
    const buffer=Buffer.from(m[2],'base64');
    const safe=String(b.name).replace(/[^a-zA-Z0-9._-]/g,'-');
    const folder=String(b.folder||'media').replace(/[^a-zA-Z0-9/_-]/g,'');
    const blob=await put(`${folder}/${Date.now()}-${safe}`,buffer,{access:'public',token:process.env.BLOB_READ_WRITE_TOKEN,contentType:m[1],addRandomSuffix:true});
    return res.status(200).json({url:blob.url});
  }catch(e){console.error(e);return res.status(500).json({error:e.message||'Upload failed'});}
};
