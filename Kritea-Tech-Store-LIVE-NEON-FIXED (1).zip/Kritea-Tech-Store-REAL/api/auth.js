const { createHmac, timingSafeEqual } = require('crypto');

const COOKIE = 'kt_session';
const isProd = process.env.VERCEL === '1' || process.env.NODE_ENV === 'production';

function secret(){
  const s = process.env.AUTH_SECRET;
  if(!s) throw new Error('AUTH_SECRET is not configured');
  return s;
}
function sign(payload){
  return createHmac('sha256', secret()).update(payload).digest('base64url');
}
function makeToken(email){
  const payload = Buffer.from(JSON.stringify({email,exp:Date.now()+1000*60*60*24*7})).toString('base64url');
  return `${payload}.${sign(payload)}`;
}
function readToken(req){
  const raw=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(COOKIE+'='));
  return raw?decodeURIComponent(raw.slice(COOKIE.length+1)):'';
}
function valid(req){
  const token=readToken(req); if(!token) return false;
  const [payload,sig]=token.split('.'); if(!payload||!sig) return false;
  const expected=sign(payload);
  try{
    if(sig.length!==expected.length || !timingSafeEqual(Buffer.from(sig),Buffer.from(expected))) return false;
  }catch{return false}
  try{
    const data=JSON.parse(Buffer.from(payload,'base64url').toString());
    return data.exp>Date.now() && data.email===process.env.ADMIN_EMAIL;
  }catch{return false}
}
function setCookie(res,token,maxAge){
  const parts=[`${COOKIE}=${encodeURIComponent(token)}`,`Max-Age=${maxAge}`,'Path=/','HttpOnly','SameSite=Lax'];
  if(isProd) parts.push('Secure');
  res.setHeader('Set-Cookie',parts.join('; '));
}
module.exports = async (req,res)=>{
  res.setHeader('Cache-Control','no-store');
  if(req.method==='GET') return res.status(200).json({authenticated:valid(req),email:valid(req)?process.env.ADMIN_EMAIL:null});
  if(req.method!=='POST') return res.status(405).json({error:'Method not allowed'});
  let body=req.body||{};
  if(typeof body==='string'){try{body=JSON.parse(body)}catch{body={}}}
  const action=body.action;
  if(action==='login'){
    if(!process.env.ADMIN_EMAIL||!process.env.ADMIN_PASSWORD||!process.env.AUTH_SECRET) return res.status(500).json({error:'Admin environment variables are missing'});
    if(body.email!==process.env.ADMIN_EMAIL || body.password!==process.env.ADMIN_PASSWORD) return res.status(401).json({error:'Email ose password i gabuar'});
    setCookie(res,makeToken(process.env.ADMIN_EMAIL),60*60*24*7);
    return res.status(200).json({ok:true,email:process.env.ADMIN_EMAIL});
  }
  if(action==='logout'){
    setCookie(res,'',0);
    return res.status(200).json({ok:true});
  }
  return res.status(400).json({error:'Unknown action'});
};
module.exports.isAdmin=valid;
