const { neon } = require('@neondatabase/serverless');
const { isAdmin } = require('./auth');

const TABLES={
  products:{json:['specifications','images','colors','storage_options','sim_options','variants'],pk:'id',publicFilter:'hidden = false',order:'created_at DESC'},
  orders:{json:['customer','items'],pk:'id',adminOnly:true,order:'created_at DESC'},
  service_requests:{json:['photo_urls'],pk:'id',adminOnly:true,order:'created_at DESC'},
  partners:{json:[],pk:'id',publicFilter:'active = true',order:'sort_order ASC, created_at DESC'},
  pages:{json:[],pk:'slug',order:'slug ASC'},
  homepage_sections:{json:[],pk:'id',publicFilter:'active = true',order:'sort_order ASC'},
  settings:{json:['value'],pk:'key',order:'key ASC'},
  categories:{json:[],pk:'id',publicFilter:'active = true',order:'created_at DESC'},
  brands:{json:[],pk:'id',publicFilter:'active = true',order:'name ASC'}
};
function sql(){if(!process.env.DATABASE_URL) throw new Error('DATABASE_URL is not configured');return neon(process.env.DATABASE_URL)}
function tableName(t){return t.replace(/[^a-z0-9_]/gi,'')}
function parseBody(req){let b=req.body||{};if(typeof b==='string'){try{b=JSON.parse(b)}catch{b={}}}return b}
function normalize(obj,def){
  const out={};
  for(const [k,v] of Object.entries(obj||{})){
    if(!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(k)) continue;
    if(def.json.includes(k)) out[k]=JSON.stringify(v==null?null:v);
    else out[k]=v;
  }
  return out;
}
async function upsertRow(t,obj){
  const def=TABLES[t], row=normalize(obj,def), keys=Object.keys(row);
  if(!keys.length) throw new Error('No data');
  const vals=keys.map(k=>row[k]);
  const placeholders=keys.map((k,i)=>def.json.includes(k)?`$${i+1}::jsonb`:`$${i+1}`);
  const conflict=def.pk;
  const updates=keys.filter(k=>k!==conflict).map(k=>`"${k}"=EXCLUDED."${k}"`);
  const text=`INSERT INTO public."${tableName(t)}" (${keys.map(k=>`"${k}"`).join(',')}) VALUES (${placeholders.join(',')}) ON CONFLICT ("${conflict}") DO ${updates.length?'UPDATE SET '+updates.join(','):'NOTHING'} RETURNING *`;
  const rows=await sql().query(text,vals);return rows[0];
}
async function createRow(t,obj){
  const def=TABLES[t], row=normalize(obj,def), keys=Object.keys(row), vals=keys.map(k=>row[k]);
  const placeholders=keys.map((k,i)=>def.json.includes(k)?`$${i+1}::jsonb`:`$${i+1}`);
  const text=`INSERT INTO public."${tableName(t)}" (${keys.map(k=>`"${k}"`).join(',')}) VALUES (${placeholders.join(',')}) RETURNING *`;
  const rows=await sql().query(text,vals);return rows[0];
}
async function getRows(t,admin,id){
  const def=TABLES[t];let where=[];let vals=[];
  if(def.adminOnly&&!admin) throw Object.assign(new Error('Unauthorized'),{status:401});
  if(def.publicFilter&&!admin) where.push(def.publicFilter);
  if(id){where.push(`"${def.pk}"=$1`);vals.push(id)}
  const text=`SELECT * FROM public."${tableName(t)}" ${where.length?'WHERE '+where.join(' AND '):''} ORDER BY ${def.order||'created_at DESC'}`;
  return await sql().query(text,vals);
}
module.exports=async(req,res)=>{
  res.setHeader('Cache-Control','no-store');
  try{
    if(!process.env.DATABASE_URL) return res.status(500).json({error:'DATABASE_URL is missing'});
    const url=new URL(req.url,'http://localhost');const t=url.searchParams.get('table');const id=url.searchParams.get('id');
    if(!TABLES[t]) return res.status(400).json({error:'Invalid table'});
    const admin=isAdmin(req);
    if(req.method==='GET'){
      const rows=await getRows(t,admin,id);
      return res.status(200).json(id?(rows[0]||null):rows);
    }
    if(req.method==='POST'){
      const b=parseBody(req);const action=b.action||'upsert';
      if(action==='create' && (t==='orders'||t==='service_requests')){
        const row=await createRow(t,b.data||{});return res.status(200).json(row);
      }
      if(!admin) return res.status(401).json({error:'Admin login required'});
      const row=await upsertRow(t,b.data||{});return res.status(200).json(row);
    }
    if(req.method==='DELETE'){
      if(!admin) return res.status(401).json({error:'Admin login required'});
      if(!id) return res.status(400).json({error:'Missing id'});
      await sql().query(`DELETE FROM public."${tableName(t)}" WHERE "${TABLES[t].pk}"=$1`,[id]);
      return res.status(200).json({ok:true});
    }
    return res.status(405).json({error:'Method not allowed'});
  }catch(e){console.error(e);return res.status(e.status||500).json({error:e.message||'Server error'});}
};
